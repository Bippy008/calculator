package kg.geektech.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView tvResult;
    private Integer firstVar, secondVar;
    private Boolean isClickOperation = false;
    private String operation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvResult = findViewById(R.id.tv_result);
    }

    public void onNumberClick(View view) {
        switch (view.getId()) {
            case R.id.btn_one:
                //кнопка 1
                setNumber("1");
                break;
            case R.id.btn_two:
                //кнопка 2
                setNumber("2");
                break;
            case R.id.btn_clear:
                tvResult.setText("0");
                firstVar = 0;
                secondVar = 0;
                isClickOperation = false;
                break;
        }
    }

    public void setNumber(String num) {
        if (tvResult.getText().toString().equals("0")) {
            tvResult.setText(num);
        } else if (isClickOperation) {
            tvResult.setText(num);
        } else {
            tvResult.append(num);
        }
        isClickOperation = false;
    }

    public void onOperationClick(View view) {
        switch (view.getId()) {
            case R.id.btn_plus:
                firstVar = Integer.parseInt(tvResult.getText().toString());
                isClickOperation = true;
                operation = "+";
                break;
            case R.id.btn_equal:
                secondVar = Integer.parseInt(tvResult.getText().toString());
                Integer result = 0;
                switch (operation) {
                    case "+":
                        result = firstVar + secondVar;
                        break;
                    case "-":
                        result = firstVar - secondVar;
                        break;
                }
                tvResult.setText(result.toString());
                isClickOperation = true;
                break;
        }
    }
}